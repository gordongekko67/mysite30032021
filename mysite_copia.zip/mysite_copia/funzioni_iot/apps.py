from django.apps import AppConfig


class FunzioniIotConfig(AppConfig):
    name = 'funzioni_iot'
